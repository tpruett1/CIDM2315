﻿namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            int lines = 1;
            int colums = 0;
            int count = 0;
            var clear = false;
            int spaces = 0;
            Console.WriteLine("Assign a value to N:");
            n = Convert.ToInt16(Console.ReadLine());
            while(n>=lines)
            {
                count = lines;
                spaces = lines - 1;

                while(lines>colums)
                {
                    while(spaces<n-1)
                    {
                        Console.Write(" ");
                        spaces++;
                    }

                    Console.Write(count);
                    colums++;

                    if(lines==colums)
                    {
                        clear=true;
                    }
                }

                lines++;
                Console.WriteLine();
                if(clear)
                {
                    colums=0;
                    clear=false;
                }
                
                
                
            }


        }
    }
}